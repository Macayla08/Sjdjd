package com.example.demo.controller;

import com.example.demo.*;
import com.example.demo.model.FACT_BOOK;
import com.example.demo.service.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
public class SearchDemoController {
    @Autowired
    private BookService books;
    //is called when search button is pressed and works with the service class to interact with the database and
    // the correct data
    @GetMapping("/search")
    public String search(@RequestParam("query") String query, Model model){
        List<FACT_BOOK> results = books.searchBooks(query);
        model.addAttribute("results", results);
        return "searchdemo";
    }
}
