package com.example.demo.repository;

import com.example.demo.model.*;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;
@Repository
//searches through the database by the title
public interface bookrepo extends JpaRepository<FACT_BOOK,Integer> {
    List<FACT_BOOK> findBybookTitleContainingIgnoreCase(String Title);

}
