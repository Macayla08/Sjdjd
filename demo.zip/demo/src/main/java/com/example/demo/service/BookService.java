package com.example.demo.service;
import com.example.demo.model.*;
import com.example.demo.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;


@Service
public class BookService {
    @Autowired
    private bookrepo bookrepository;
//Calls the repository to search through the database
    public List<FACT_BOOK> searchBooks(String query){
        return bookrepository.findBybookTitleContainingIgnoreCase(query);
    }
}
