package com.example.demo.model;


import jakarta.persistence.*;

@Entity
@Table(name = "`Fact_book`")
public class FACT_BOOK {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column
    private int bookNum;
    @Column
    private String bookTitle;
    @Column
    private int bookYear;
    @Column
    private double bookCost;
    @Column
    private String bookSubject;
    @Column
    private int patronID;

    public int getBookNum() {
        return bookNum;
    }

    public void setBookNum(int booknum) {
        bookNum = booknum;
    }

    public String getBookTitle() {
        return bookTitle;
    }

    public void setBookTitle(String booktitle) {
        bookTitle = booktitle;
    }

    public int getBookYear() {
        return bookYear;
    }

    public void setBookYear(int bookyear) {
        bookYear = bookyear;
    }

    public double getBookCost() {
        return bookCost;
    }

    public void setBookCost(double bookcost) {
        bookCost = bookcost;
    }

    public String getBookSubject() {
        return bookSubject;
    }

    public void setBookSubject(String booksubject) {
        bookSubject = booksubject;
    }

    public int getPatronID() {
        return patronID;
    }

    public void setPatronID(int PatronID) {
        patronID = PatronID;
    }
}
